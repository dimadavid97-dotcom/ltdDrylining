FILES TO UPLOAD TO THE SAME GITHUB REPOSITORY ROOT:
- index.html
- about.html
- services.html
- contact.html
- terms.html
- style.css
- script.js

KEEP YOUR EXISTING JPG IMAGES IN THE SAME ROOT FOLDER.
